import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyA2Ml7QMBlaUyKZyFu7j83I5Y2eM1COgkc",
  authDomain: "board7-4373c.firebaseapp.com",
  databaseURL: "https://board7-4373c-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "board7-4373c",
  storageBucket: "board7-4373c.firebasestorage.app",
  messagingSenderId: "298011654216",
  appId: "1:298011654216:web:084fb0f220aa7be5b4807d"
};

// Firebase 초기화
const app = initializeApp(firebaseConfig);

// Firebase 서비스 초기화
export const db = getDatabase(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

export default app; 