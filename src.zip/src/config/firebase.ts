import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyAJIU9ojxqTmqlJAfOZyxDu2DL5GrtzAjM",
  authDomain: "board7-dev.firebaseapp.com",
  databaseURL: "https://board7-dev-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "board7-dev",
  storageBucket: "board7-dev.firebasestorage.app",
  messagingSenderId: "324461926704",
  appId: "1:324461926704:web:35cb2a4d01df21d02450f5"
};

// Firebase 앱이 이미 초기화되어 있는지 확인
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Firebase 서비스 초기화
export const auth = getAuth(app);
export const db = getDatabase(app);

export default app; 