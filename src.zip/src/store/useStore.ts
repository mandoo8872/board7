import { create } from 'zustand';
import { Tool, Stroke, Cell } from '../types';

interface BoardState {
  // 도구 상태
  currentTool: Tool;
  setCurrentTool: (tool: Tool) => void;
  
  // 그리기 상태
  isDrawing: boolean;
  setIsDrawing: (isDrawing: boolean) => void;
  
  // 스트로크 관리
  strokes: Stroke[];
  addStroke: (stroke: Stroke) => void;
  clearStrokes: () => void;
  
  // 셀 관리
  cells: Cell[];
  addCell: (cell: Cell) => void;
  updateCell: (id: string, updates: Partial<Cell>) => void;
  removeCell: (id: string) => void;
  
  // 확대/축소
  scale: number;
  setScale: (scale: number) => void;
  
  // 그리드 설정
  showGrid: boolean;
  setShowGrid: (show: boolean) => void;
  gridSize: number;
  setGridSize: (size: number) => void;
}

export const useStore = create<BoardState>((set) => ({
  // 도구 상태
  currentTool: 'select',
  setCurrentTool: (tool) => set({ currentTool: tool }),
  
  // 그리기 상태
  isDrawing: false,
  setIsDrawing: (isDrawing) => set({ isDrawing }),
  
  // 스트로크 관리
  strokes: [],
  addStroke: (stroke) => set((state) => ({ 
    strokes: [...state.strokes, stroke] 
  })),
  clearStrokes: () => set({ strokes: [] }),
  
  // 셀 관리
  cells: [],
  addCell: (cell) => set((state) => ({ 
    cells: [...state.cells, cell] 
  })),
  updateCell: (id, updates) => set((state) => ({
    cells: state.cells.map((cell) =>
      cell.id === id ? { ...cell, ...updates } : cell
    ),
  })),
  removeCell: (id) => set((state) => ({
    cells: state.cells.filter((cell) => cell.id !== id),
  })),
  
  // 확대/축소
  scale: 1,
  setScale: (scale) => set({ scale }),
  
  // 그리드 설정
  showGrid: true,
  setShowGrid: (show) => set({ showGrid: show }),
  gridSize: 20,
  setGridSize: (size) => set({ gridSize: size }),
})); 