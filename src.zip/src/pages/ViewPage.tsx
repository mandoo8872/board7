import React from 'react';
import Canvas from '../components/Canvas';
import Toolbar from '../components/toolbar/Toolbar';

const ViewPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4">
          <h1 className="text-3xl font-bold text-gray-900">뷰어 페이지</h1>
        </div>
      </header>
      <main>
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <div className="relative w-full h-[calc(100vh-8rem)]">
            <Canvas isViewPage={true} />
            <Toolbar />
          </div>
        </div>
      </main>
    </div>
  );
};

export default ViewPage; 