import React, { useState, useRef } from 'react';
import { CanvasWrapper } from '../components/CanvasWrapper';
import { exportBoardData, importBoardData, downloadBoardData, validateBoardData } from '../utils/boardExport';
import ConfirmModal from '../components/modals/ConfirmModal';
import Canvas from '../components/Canvas';
import Toolbar from '../components/toolbar/Toolbar';

const AdminPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const boardData = await exportBoardData();
      downloadBoardData(boardData);
    } catch (error) {
      setError('보드 저장 중 오류가 발생했습니다.');
      console.error('보드 저장 실패:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const data = JSON.parse(text);

      if (!validateBoardData(data)) {
        setError('잘못된 보드 데이터 형식입니다.');
        return;
      }

      setIsConfirmModalOpen(true);
    } catch (error) {
      setError('파일 읽기 중 오류가 발생했습니다.');
      console.error('파일 읽기 실패:', error);
    }
  };

  const handleConfirmImport = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const file = fileInputRef.current?.files?.[0];
      if (!file) return;

      const text = await file.text();
      const data = JSON.parse(text);
      await importBoardData(data);
    } catch (error) {
      setError('보드 복원 중 오류가 발생했습니다.');
      console.error('보드 복원 실패:', error);
    } finally {
      setIsLoading(false);
      setIsConfirmModalOpen(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4">
          <h1 className="text-3xl font-bold text-gray-900">관리자 페이지</h1>
        </div>
      </header>
      <main>
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <div className="relative w-full h-[calc(100vh-8rem)]">
            <Canvas isViewPage={false} />
            <Toolbar />
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminPage; 