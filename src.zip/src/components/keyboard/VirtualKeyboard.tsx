import React, { useState, useCallback } from 'react';

interface VirtualKeyboardProps {
  onInput: (text: string) => void;
  onClose: () => void;
  initialValue?: string;
}

const VirtualKeyboard: React.FC<VirtualKeyboardProps> = ({
  onInput,
  onClose,
  initialValue = '',
}) => {
  const [text, setText] = useState(initialValue);
  const [isKorean, setIsKorean] = useState(false);

  const handleKeyClick = useCallback((key: string) => {
    setText(prev => prev + key);
    onInput(text + key);
  }, [text, onInput]);

  const handleBackspace = useCallback(() => {
    setText(prev => {
      const newText = prev.slice(0, -1);
      onInput(newText);
      return newText;
    });
  }, [onInput]);

  const handleClear = useCallback(() => {
    setText('');
    onInput('');
  }, [onInput]);

  const handleLanguageToggle = useCallback(() => {
    setIsKorean(prev => !prev);
  }, []);

  const handleClose = useCallback(() => {
    onClose();
  }, [onClose]);

  const numberKeys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
  const koreanKeys = ['ㅂ', 'ㅈ', 'ㄷ', 'ㄱ', 'ㅅ', 'ㅛ', 'ㅕ', 'ㅑ', 'ㅐ', 'ㅔ'];
  const englishKeys = ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'];
  const symbolKeys = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')'];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4 z-50">
      <div className="max-w-2xl mx-auto">
        {/* 입력창 */}
        <div className="flex items-center gap-2 mb-4">
          <input
            type="text"
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              onInput(e.target.value);
            }}
            className="flex-1 px-4 py-2 border rounded-lg"
            placeholder="텍스트를 입력하세요"
          />
          <button
            onClick={handleClear}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            지우기
          </button>
          <button
            onClick={handleClose}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            닫기
          </button>
        </div>

        {/* 키보드 레이아웃 */}
        <div className="grid grid-cols-10 gap-2">
          {/* 숫자 키 */}
          {numberKeys.map((key) => (
            <button
              key={key}
              onClick={() => handleKeyClick(key)}
              className="p-2 text-center border rounded hover:bg-gray-100"
            >
              {key}
            </button>
          ))}

          {/* 한글/영문 키 */}
          {(isKorean ? koreanKeys : englishKeys).map((key) => (
            <button
              key={key}
              onClick={() => handleKeyClick(key)}
              className="p-2 text-center border rounded hover:bg-gray-100"
            >
              {key}
            </button>
          ))}

          {/* 기호 키 */}
          {symbolKeys.map((key) => (
            <button
              key={key}
              onClick={() => handleKeyClick(key)}
              className="p-2 text-center border rounded hover:bg-gray-100"
            >
              {key}
            </button>
          ))}

          {/* 특수 키 */}
          <button
            onClick={handleBackspace}
            className="col-span-2 p-2 text-center border rounded hover:bg-gray-100"
          >
            ←
          </button>
          <button
            onClick={handleLanguageToggle}
            className="col-span-2 p-2 text-center border rounded hover:bg-gray-100"
          >
            {isKorean ? '한글' : '영문'}
          </button>
          <button
            onClick={() => handleKeyClick(' ')}
            className="col-span-4 p-2 text-center border rounded hover:bg-gray-100"
          >
            스페이스
          </button>
        </div>
      </div>
    </div>
  );
};

export default VirtualKeyboard; 