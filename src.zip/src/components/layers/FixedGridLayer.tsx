import React from 'react';
import { useFixedGrid } from '../../hooks/useFixedGrid';
import { useSelectedCell } from '../../hooks/useSelectedCell';
import FixedGridCell from '../FixedGrid/FixedGridCell';
import FixedGridStylePanel from '../FixedGrid/FixedGridStylePanel';

interface FixedGridLayerProps {
  isViewPage: boolean;
}

const FixedGridLayer: React.FC<FixedGridLayerProps> = ({ isViewPage }) => {
  const { cells, updateCellText } = useFixedGrid(isViewPage);
  const { selectedCell, selectCell } = useSelectedCell();

  return (
    <div className="absolute inset-0 z-[1]">
      {cells.map((cell) => (
        <FixedGridCell
          key={cell.id}
          cell={cell}
          isViewPage={isViewPage}
          onUpdateText={updateCellText}
          onSelect={selectCell}
          isSelected={selectedCell?.id === cell.id}
        />
      ))}

      {!isViewPage && selectedCell && (
        <FixedGridStylePanel cell={selectedCell} />
      )}
    </div>
  );
};

export default FixedGridLayer; 