import React, { useRef, useEffect } from 'react';
import { useDrawLayer } from '../../hooks/useDrawLayer';

interface DrawLayerProps {
  isViewPage: boolean;
}

const DrawLayer: React.FC<DrawLayerProps> = ({ isViewPage }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const {
    isDrawing,
    currentPoints,
    currentTool,
    strokes,
    startDrawing,
    draw,
    endDrawing,
  } = useDrawLayer(isViewPage);

  // 캔버스 크기 설정
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      if (!parent) return;

      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    return () => window.removeEventListener('resize', resizeCanvas);
  }, []);

  // 스트로크 렌더링
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 캔버스 초기화
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 저장된 스트로크 렌더링
    strokes.forEach(stroke => {
      if (stroke.points.length < 2) return;

      ctx.beginPath();
      ctx.moveTo(stroke.points[0][0], stroke.points[0][1]);

      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i][0], stroke.points[i][1]);
      }

      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
    });

    // 현재 그리는 중인 스트로크 렌더링
    if (isDrawing && currentPoints.length > 1) {
      ctx.beginPath();
      ctx.moveTo(currentPoints[0][0], currentPoints[0][1]);

      for (let i = 1; i < currentPoints.length; i++) {
        ctx.lineTo(currentPoints[i][0], currentPoints[i][1]);
      }

      ctx.strokeStyle = currentTool === 'pen' ? '#000000' : '#ffffff';
      ctx.lineWidth = currentTool === 'pen' ? 4 : 20;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
    }
  }, [strokes, isDrawing, currentPoints, currentTool]);

  // 포인터 이벤트 핸들러
  const handlePointerDown = (e: React.PointerEvent) => {
    if (!isViewPage) return;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    startDrawing(x, y);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isViewPage) return;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    draw(x, y);
  };

  const handlePointerUp = () => {
    if (!isViewPage) return;
    endDrawing();
  };

  if (!isViewPage) return null;

  return (
    <canvas
      ref={canvasRef}
      className="absolute top-0 left-0 w-full h-full z-10"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
    />
  );
};

export default DrawLayer; 