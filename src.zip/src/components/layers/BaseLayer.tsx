import React, { useEffect, useState, useCallback } from 'react';
import { ref, onValue, update } from 'firebase/database';
import { database } from '../../utils/firebase';
import { BoardObject } from '../../types';
import BoxShape from '../shapes/BoxShape';
import TextShape from '../shapes/TextShape';
import ImageShape from '../shapes/ImageShape';
import CheckboxTextShape from '../shapes/CheckboxTextShape';

interface BaseLayerProps {
  isViewPage?: boolean;
}

const BaseLayer: React.FC<BaseLayerProps> = ({ isViewPage = false }) => {
  const [shapes, setShapes] = useState<BoardObject[]>([]);

  useEffect(() => {
    const shapesRef = ref(database, 'sharedBoardData/shapes');
    
    const unsubscribe = onValue(shapesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const shapesArray = Object.values(data) as BoardObject[];
        // ViewPage에서는 모든 객체의 selected를 false로 설정
        const processedShapes = shapesArray.map(shape => ({
          ...shape,
          selected: isViewPage ? false : shape.selected
        }));
        // zIndex 기준으로 정렬
        processedShapes.sort((a, b) => a.zIndex - b.zIndex);
        setShapes(processedShapes);
      } else {
        setShapes([]);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [isViewPage]);

  // 전역 클릭 이벤트 핸들러
  const handleLayerClick = useCallback(async (e: React.MouseEvent) => {
    // 레이어 자체를 클릭한 경우에만 모든 객체의 선택 해제
    if (e.target === e.currentTarget) {
      const updates: { [key: string]: { selected: boolean } } = {};
      shapes.forEach(shape => {
        updates[`sharedBoardData/shapes/${shape.id}/selected`] = { selected: false };
      });
      
      try {
        await update(ref(database), updates);
      } catch (error) {
        console.error('선택 상태 업데이트 실패:', error);
      }
    }
  }, [shapes]);

  return (
    <div 
      className="absolute inset-0"
      onClick={handleLayerClick}
    >
      {shapes.map((shape) => {
        const commonProps = {
          ...shape,
          isViewPage,
        };

        switch (shape.type) {
          case 'box':
            return <BoxShape key={shape.id} {...commonProps} />;
          case 'text':
            return <TextShape key={shape.id} {...commonProps} />;
          case 'image':
            return <ImageShape key={shape.id} {...commonProps} />;
          case 'checkbox-text':
            return <CheckboxTextShape key={shape.id} {...commonProps} />;
          default:
            return null;
        }
      })}
    </div>
  );
};

export default BaseLayer; 