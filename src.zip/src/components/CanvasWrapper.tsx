import React, { useState, useCallback } from 'react';
import { useDrawLayer } from '../hooks/useDrawLayer';
import { useFixedGridLayer } from '../hooks/useFixedGridLayer';
import { useBackgroundImage } from '../hooks/useBackgroundImage';
import { useSelectedCells } from '../hooks/useSelectedCells';
import { useUpdateCellText } from '../hooks/useUpdateCellText';
import { useUpdateCellStyle } from '../hooks/useUpdateCellStyle';
import { useMergeCells } from '../hooks/useMergeCells';
import { useSplitCells } from '../hooks/useSplitCells';
import { useUndoRedo } from '../hooks/useUndoRedo';
import { useExcelPaste } from '../hooks/useExcelPaste';
import { useImageUpload } from '../hooks/useImageUpload';
import { Tool } from '../types/tool';
import AdminToolbar from './toolbar/AdminToolbar';
import ZoomControls from './zoom/ZoomControls';

interface CanvasWrapperProps {
  isAdmin: boolean;
}

const CanvasWrapper: React.FC<CanvasWrapperProps> = ({ isAdmin }) => {
  const [currentTool, setCurrentTool] = useState<Tool>('select');
  const [strokeColor, setStrokeColor] = useState('#000000');
  const [strokeWidth, setStrokeWidth] = useState(2);
  const [gridVisible, setGridVisible] = useState(true);
  const [gridSize, setGridSize] = useState(32);
  const [zoom, setZoom] = useState(1.0);

  const {
    strokes,
    startDrawing,
    draw,
    endDrawing,
    clearStrokes,
    undoStroke,
    redoStroke,
  } = useDrawLayer();

  const {
    cells,
    selectedCells,
    startSelection,
    updateSelection,
    endSelection,
    clearSelection,
    toggleCellSelection,
  } = useFixedGridLayer();

  const { backgroundImage, setBackgroundImage } = useBackgroundImage();
  const { updateCellText } = useUpdateCellText();
  const { updateCellStyle } = useUpdateCellStyle();
  const { mergeCells } = useMergeCells();
  const { splitCells } = useSplitCells();
  const { canUndo, canRedo, undo, redo } = useUndoRedo();
  const { handleExcelPaste } = useExcelPaste();
  const { handleImageUpload } = useImageUpload();

  const handleToolChange = useCallback((tool: Tool) => {
    setCurrentTool(tool);
    if (tool !== 'select') {
      clearSelection();
    }
  }, [clearSelection]);

  const handleColorChange = useCallback((color: string) => {
    setStrokeColor(color);
  }, []);

  const handleStrokeWidthChange = useCallback((width: number) => {
    setStrokeWidth(width);
  }, []);

  const handleGridToggle = useCallback(() => {
    setGridVisible(prev => !prev);
  }, []);

  const handleGridSizeChange = useCallback((size: number) => {
    setGridSize(size);
  }, []);

  const handleZoomChange = useCallback((newZoom: number) => {
    setZoom(newZoom);
  }, []);

  return (
    <div className="relative w-full h-full overflow-hidden">
      {isAdmin && (
        <AdminToolbar
          currentTool={currentTool}
          onToolChange={handleToolChange}
          onColorChange={handleColorChange}
          onStrokeWidthChange={handleStrokeWidthChange}
          onGridToggle={handleGridToggle}
          onGridSizeChange={handleGridSizeChange}
          onUndo={undo}
          onRedo={redo}
          onExport={() => {}}
          onImport={() => {}}
          onExcelPaste={handleExcelPaste}
          onImageUpload={handleImageUpload}
          canUndo={canUndo}
          canRedo={canRedo}
          gridVisible={gridVisible}
          gridSize={gridSize}
          strokeWidth={strokeWidth}
          strokeColor={strokeColor}
        />
      )}
      <div
        className="relative w-full h-full"
        style={{
          transform: `scale(${zoom})`,
          transformOrigin: 'center center',
        }}
      >
        {/* 배경 이미지 레이어 */}
        {backgroundImage && (
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${backgroundImage})` }}
          />
        )}

        {/* 그리기 레이어 */}
        <svg
          className="absolute inset-0"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={endDrawing}
          onMouseLeave={endDrawing}
        >
          {strokes.map((stroke, index) => (
            <path
              key={index}
              d={stroke.path}
              stroke={stroke.color}
              strokeWidth={stroke.width}
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          ))}
        </svg>

        {/* 고정 그리드 레이어 */}
        <div
          className="absolute inset-0"
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(auto-fill, ${gridSize}px)`,
            gridTemplateRows: `repeat(auto-fill, ${gridSize}px)`,
            gap: '1px',
            backgroundColor: gridVisible ? '#e5e7eb' : 'transparent',
          }}
        >
          {cells.map((cell) => (
            <div
              key={cell.id}
              className={`relative ${
                cell.merged ? 'hidden' : 'bg-white'
              }`}
              style={{
                gridColumn: cell.mergedRoot ? 'span 1' : `span ${cell.colspan || 1}`,
                gridRow: cell.mergedRoot ? 'span 1' : `span ${cell.rowspan || 1}`,
              }}
              onClick={() => isAdmin && toggleCellSelection(cell.id)}
              onMouseDown={(e) => {
                if (isAdmin && e.button === 0) {
                  startSelection(cell.id);
                }
              }}
              onMouseMove={() => {
                if (isAdmin) {
                  updateSelection(cell.id);
                }
              }}
              onMouseUp={() => {
                if (isAdmin) {
                  endSelection();
                }
              }}
            >
              {cell.mergedRoot ? null : (
                <div
                  className={`w-full h-full p-1 ${
                    selectedCells.includes(cell.id) ? 'ring-2 ring-blue-500' : ''
                  }`}
                  style={{
                    fontSize: cell.fontSize,
                    color: cell.fontColor,
                    backgroundColor: cell.backgroundColor,
                    border: cell.borderWidth ? `${cell.borderWidth}px ${cell.borderStyle} ${cell.borderColor}` : 'none',
                    textAlign: cell.textAlign,
                    verticalAlign: cell.verticalAlign,
                  }}
                >
                  {cell.text}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      <ZoomControls zoom={zoom} onZoomChange={handleZoomChange} />
    </div>
  );
};

export default CanvasWrapper; 