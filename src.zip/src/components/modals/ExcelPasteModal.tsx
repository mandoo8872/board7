import React, { useState } from 'react';
import { useExcelPaste } from '../../hooks/useExcelPaste';

interface ExcelPasteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ExcelPasteModal: React.FC<ExcelPasteModalProps> = ({ isOpen, onClose }) => {
  const [excelData, setExcelData] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { parseExcelData } = useExcelPaste();

  const handlePaste = async () => {
    if (!excelData.trim()) {
      setError('엑셀 데이터를 붙여넣어주세요.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await parseExcelData(excelData);
      if (result.success) {
        onClose();
      } else {
        setError('데이터 처리 중 오류가 발생했습니다.');
      }
    } catch (error) {
      setError('데이터 처리 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-[600px] max-w-[90vw]">
        <h2 className="text-xl font-bold mb-4">엑셀 데이터 붙여넣기</h2>
        
        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-2">
            엑셀에서 복사한 데이터를 아래 입력창에 붙여넣어주세요.
          </p>
          <textarea
            value={excelData}
            onChange={(e) => setExcelData(e.target.value)}
            className="w-full h-48 p-2 border rounded resize-none"
            placeholder="엑셀 데이터를 여기에 붙여넣으세요..."
          />
        </div>

        {error && (
          <div className="mb-4 p-2 bg-red-100 text-red-700 rounded">
            {error}
          </div>
        )}

        <div className="flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded"
            disabled={isLoading}
          >
            취소
          </button>
          <button
            onClick={handlePaste}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
            disabled={isLoading}
          >
            {isLoading ? '처리 중...' : '붙여넣기'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExcelPasteModal; 