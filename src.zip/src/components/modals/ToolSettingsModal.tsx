import React from 'react';
import { ToolAutoSwitchSettings } from '../../types/toolSettings';

interface ToolSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ToolAutoSwitchSettings;
  onSettingsChange: (settings: ToolAutoSwitchSettings) => void;
}

const ToolSettingsModal: React.FC<ToolSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSettingsChange,
}) => {
  if (!isOpen) return null;

  const handleToggle = (key: keyof ToolAutoSwitchSettings) => {
    onSettingsChange({
      ...settings,
      [key]: !settings[key],
    });
  };

  const handleTimeoutChange = (value: string) => {
    const timeout = Math.max(1, Math.min(10, parseInt(value, 10))) * 1000;
    onSettingsChange({
      ...settings,
      timeout,
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">도구 자동 전환 설정</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4">
          {/* 도구 자동 전환 사용 여부 */}
          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium">도구 자동 전환</label>
              <p className="text-sm text-gray-500">사용하지 않을 때 자동으로 선택 도구로 전환</p>
            </div>
            <button
              onClick={() => handleToggle('enabled')}
              className={`w-12 h-6 rounded-full transition-colors ${
                settings.enabled ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full transform transition-transform ${
                  settings.enabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* 자동 전환 대기 시간 */}
          <div>
            <label className="font-medium block mb-2">
              자동 전환 대기 시간 ({settings.timeout / 1000}초)
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={settings.timeout / 1000}
              onChange={(e) => handleTimeoutChange(e.target.value)}
              className="w-full"
            />
          </div>

          {/* T/T 입력 시 자동 전환 비활성화 */}
          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium">T/T 입력 시 자동 전환 비활성화</label>
              <p className="text-sm text-gray-500">텍스트 입력 중에는 자동 전환되지 않음</p>
            </div>
            <button
              onClick={() => handleToggle('disableOnTTInput')}
              className={`w-12 h-6 rounded-full transition-colors ${
                settings.disableOnTTInput ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full transform transition-transform ${
                  settings.disableOnTTInput ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* 마우스 정지 시 자동 전환 */}
          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium">마우스 정지 시 자동 전환</label>
              <p className="text-sm text-gray-500">마우스가 멈춰있을 때도 자동 전환 적용</p>
            </div>
            <button
              onClick={() => handleToggle('switchOnMouseStop')}
              className={`w-12 h-6 rounded-full transition-colors ${
                settings.switchOnMouseStop ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full transform transition-transform ${
                  settings.switchOnMouseStop ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* ViewPage와 설정 연동 */}
          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium">ViewPage와 설정 연동</label>
              <p className="text-sm text-gray-500">ViewPage에도 동일한 설정 적용</p>
            </div>
            <button
              onClick={() => handleToggle('syncWithViewPage')}
              className={`w-12 h-6 rounded-full transition-colors ${
                settings.syncWithViewPage ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full transform transition-transform ${
                  settings.syncWithViewPage ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={() => onSettingsChange({
              enabled: true,
              timeout: 2000,
              disableOnTTInput: true,
              switchOnMouseStop: false,
              syncWithViewPage: false,
            })}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            기본값으로 초기화
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
          >
            저장
          </button>
        </div>
      </div>
    </div>
  );
};

export default ToolSettingsModal; 