import React, { useCallback } from 'react';
import { ref, update } from 'firebase/database';
import { db } from '../../config/firebase';

interface CheckboxTextShapeProps {
  id: string;
  x: number;
  y: number;
  text: string;
  checked: boolean;
  isDragging: boolean;
  onDragStart: (e: React.MouseEvent) => void;
  onDrag: (e: React.MouseEvent) => void;
  onDragEnd: () => void;
}

const CheckboxTextShape: React.FC<CheckboxTextShapeProps> = ({
  id,
  x,
  y,
  text,
  checked,
  isDragging,
  onDragStart,
  onDrag,
  onDragEnd,
}) => {
  const handleCheckboxChange = useCallback(() => {
    const shapeRef = ref(db, `sharedBoardData/shapes/${id}`);
    update(shapeRef, { checked: !checked }).catch((error) => {
      console.error('체크박스 상태 업데이트 실패:', error);
    });
  }, [id, checked]);

  return (
    <div
      className={`absolute flex items-center gap-2 p-2 bg-white rounded-lg shadow-md cursor-move ${
        isDragging ? 'opacity-50' : ''
      }`}
      style={{
        left: x,
        top: y,
        transform: 'translate(-50%, -50%)',
      }}
      onMouseDown={onDragStart}
      onMouseMove={onDrag}
      onMouseUp={onDragEnd}
      onMouseLeave={onDragEnd}
    >
      <input
        type="checkbox"
        checked={checked}
        onChange={handleCheckboxChange}
        className="w-4 h-4"
      />
      <span className="text-sm">{text}</span>
    </div>
  );
};

export default CheckboxTextShape; 