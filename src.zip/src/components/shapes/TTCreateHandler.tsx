import React, { useState, useCallback } from 'react';
import { ref, push, set } from 'firebase/database';
import { db } from '../../config/firebase';
import VirtualKeyboard from '../keyboard/VirtualKeyboard';

interface TTCreateHandlerProps {
  onClose: () => void;
}

interface CheckboxTextShape {
  id: string;
  type: 'checkboxText';
  x: number;
  y: number;
  text: string;
  checked: boolean;
}

const TTCreateHandler: React.FC<TTCreateHandlerProps> = ({ onClose }) => {
  const [text, setText] = useState('');

  const handleTextInput = useCallback((newText: string) => {
    setText(newText);
  }, []);

  const handleKeyboardClose = useCallback(() => {
    if (text.trim()) {
      // T/T 객체 생성
      const shapesRef = ref(db, 'sharedBoardData/shapes');
      const newShapeRef = push(shapesRef);
      const newShape: CheckboxTextShape = {
        id: newShapeRef.key!,
        type: 'checkboxText',
        x: window.innerWidth / 2 - 100, // 화면 중앙
        y: 100, // 상단에서 100px
        text: text.trim(),
        checked: false,
      };

      set(newShapeRef, newShape)
        .then(() => {
          onClose();
        })
        .catch((error) => {
          console.error('T/T 객체 생성 실패:', error);
        });
    } else {
      onClose();
    }
  }, [text, onClose]);

  return (
    <VirtualKeyboard
      onInput={handleTextInput}
      onClose={handleKeyboardClose}
      initialValue={text}
    />
  );
};

export default TTCreateHandler; 