import React from 'react';
import { ImageObject } from '../../types';
import { useShapeInteraction } from '../../hooks/useShapeInteraction';

interface ImageShapeProps extends Omit<ImageObject, 'type'> {
  isViewPage?: boolean;
}

const ImageShape: React.FC<ImageShapeProps> = ({
  id,
  x,
  y,
  width,
  height,
  src,
  selected,
  resizable,
  isViewPage = false,
  ...shape
}) => {
  const {
    elementRef,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp,
  } = useShapeInteraction({
    id,
    x,
    y,
    width,
    height,
    type: 'image',
    src,
    selected,
    resizable,
    ...shape
  } as ImageObject, isViewPage);

  return (
    <div
      ref={elementRef}
      className="absolute"
      style={{
        left: x,
        top: y,
        width,
        height,
        outline: selected ? '2px solid #3b82f6' : 'none',
        cursor: 'move',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      <img
        src={src}
        alt=""
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'contain',
        }}
      />
      {selected && resizable && (
        <>
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-nw-resize" data-direction="nw" style={{ top: -4, left: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-ne-resize" data-direction="ne" style={{ top: -4, right: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-sw-resize" data-direction="sw" style={{ bottom: -4, left: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-se-resize" data-direction="se" style={{ bottom: -4, right: -4 }} />
        </>
      )}
    </div>
  );
};

export default ImageShape; 