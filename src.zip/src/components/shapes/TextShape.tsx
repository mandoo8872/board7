import React from 'react';
import { TextObject } from '../../types';
import { useShapeInteraction } from '../../hooks/useShapeInteraction';

interface TextShapeProps extends Omit<TextObject, 'type'> {
  isViewPage?: boolean;
}

const TextShape: React.FC<TextShapeProps> = ({
  id,
  x,
  y,
  width,
  height,
  text,
  fontSize,
  textAlign,
  textColor,
  textOpacity,
  backgroundColor,
  backgroundOpacity,
  selected,
  resizable,
  isViewPage = false,
  ...shape
}) => {
  const {
    elementRef,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp,
  } = useShapeInteraction({
    id,
    x,
    y,
    width,
    height,
    type: 'text',
    text,
    fontSize,
    textAlign,
    textColor,
    textOpacity,
    backgroundColor,
    backgroundOpacity,
    selected,
    resizable,
    ...shape
  } as TextObject, isViewPage);

  return (
    <div
      ref={elementRef}
      className="absolute"
      style={{
        left: x,
        top: y,
        width,
        height,
        backgroundColor,
        opacity: backgroundOpacity,
        outline: selected ? '2px solid #3b82f6' : 'none',
        cursor: 'move',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      <div
        style={{
          fontSize,
          textAlign,
          color: textColor,
          opacity: textOpacity,
        }}
      >
        {text}
      </div>
      {selected && resizable && (
        <>
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-nw-resize" data-direction="nw" style={{ top: -4, left: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-ne-resize" data-direction="ne" style={{ top: -4, right: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-sw-resize" data-direction="sw" style={{ bottom: -4, left: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-se-resize" data-direction="se" style={{ bottom: -4, right: -4 }} />
        </>
      )}
    </div>
  );
};

export default TextShape; 