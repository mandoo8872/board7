import React from 'react';
import { BoxObject } from '../../types';
import { useShapeInteraction } from '../../hooks/useShapeInteraction';

interface BoxShapeProps extends Omit<BoxObject, 'type'> {
  isViewPage?: boolean;
}

const BoxShape: React.FC<BoxShapeProps> = ({
  id,
  x,
  y,
  width,
  height,
  backgroundColor,
  backgroundOpacity,
  selected,
  resizable,
  isViewPage = false,
  ...shape
}) => {
  const {
    elementRef,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp,
  } = useShapeInteraction({
    id,
    x,
    y,
    width,
    height,
    type: 'box',
    backgroundColor,
    backgroundOpacity,
    selected,
    resizable,
    ...shape
  } as BoxObject, isViewPage);

  return (
    <div
      ref={elementRef}
      className="absolute"
      style={{
        left: x,
        top: y,
        width,
        height,
        backgroundColor,
        opacity: backgroundOpacity,
        outline: selected ? '2px solid #3b82f6' : 'none',
        cursor: 'move',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {selected && resizable && (
        <>
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-nw-resize" data-direction="nw" style={{ top: -4, left: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-ne-resize" data-direction="ne" style={{ top: -4, right: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-sw-resize" data-direction="sw" style={{ bottom: -4, left: -4 }} />
          <div className="resize-handle absolute w-3 h-3 bg-blue-500 rounded-full cursor-se-resize" data-direction="se" style={{ bottom: -4, right: -4 }} />
        </>
      )}
    </div>
  );
};

export default BoxShape; 