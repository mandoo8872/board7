import React, { useState } from 'react';
import { FixedGridCell } from '../../types/fixedGrid';
import { useUpdateCellText } from '../../hooks/useUpdateCellText';

interface FixedGridCellProps {
  cell: FixedGridCell;
  isSelected: boolean;
  isViewPage?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  onMouseDown?: (e: React.MouseEvent) => void;
  onMouseEnter?: () => void;
}

const FixedGridCell: React.FC<FixedGridCellProps> = ({
  cell,
  isSelected,
  isViewPage,
  onClick,
  onMouseDown,
  onMouseEnter,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const { updateCellText } = useUpdateCellText();

  const handleDoubleClick = () => {
    if (isViewPage || cell.merged) return;
    setIsEditing(true);
  };

  const handleBlur = () => {
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      setIsEditing(false);
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateCellText(cell.id, e.target.value);
  };

  const getJustifyContent = (align: 'left' | 'center' | 'right') => {
    switch (align) {
      case 'left':
        return 'flex-start';
      case 'center':
        return 'center';
      case 'right':
        return 'flex-end';
    }
  };

  const getAlignItems = (align: 'top' | 'middle' | 'bottom') => {
    switch (align) {
      case 'top':
        return 'flex-start';
      case 'middle':
        return 'center';
      case 'bottom':
        return 'flex-end';
    }
  };

  const style: React.CSSProperties = {
    fontSize: `${cell.fontSize}px`,
    color: cell.fontColor,
    backgroundColor: cell.backgroundColor,
    border: cell.borderWidth > 0
      ? `${cell.borderWidth}px ${cell.borderStyle} ${cell.borderColor}`
      : 'none',
    gridArea: cell.merged
      ? `${cell.row + 1} / ${cell.col + 1} / span ${cell.rowspan} / span ${cell.colspan}`
      : undefined,
    display: cell.merged && !cell.mergedRoot ? 'none' : 'flex',
    justifyContent: getJustifyContent(cell.textAlign),
    alignItems: getAlignItems(cell.verticalAlign),
  };

  return (
    <div
      className={`relative ${
        isSelected ? 'ring-2 ring-blue-500' : ''
      } ${cell.merged ? 'z-10' : ''}`}
      style={style}
      onClick={onClick}
      onMouseDown={onMouseDown}
      onMouseEnter={onMouseEnter}
      onDoubleClick={handleDoubleClick}
    >
      {isEditing ? (
        <input
          type="text"
          value={cell.text}
          onChange={handleTextChange}
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
          className="w-full h-full px-2 py-1 focus:outline-none"
          style={{
            textAlign: cell.textAlign,
          }}
          autoFocus
        />
      ) : (
        <div className="w-full h-full px-2 py-1">{cell.text}</div>
      )}
    </div>
  );
};

export default FixedGridCell; 