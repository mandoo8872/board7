import React from 'react';
import { FixedGridCell } from '../../types/fixedGrid';
import { useUpdateCellStyle } from '../../hooks/useUpdateCellStyle';
import { mergeCells, splitCells } from '../../utils/mergeUtils';

interface FixedGridStylePanelProps {
  cell: FixedGridCell;
  selectedCells: FixedGridCell[];
  onMerge: (cells: FixedGridCell[]) => void;
  onSplit: (cells: FixedGridCell[]) => void;
}

const FixedGridStylePanel: React.FC<FixedGridStylePanelProps> = ({
  cell,
  selectedCells,
  onMerge,
  onSplit,
}) => {
  const { updateCellStyle } = useUpdateCellStyle();

  const handleFontSizeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fontSize = parseInt(e.target.value);
    if (!isNaN(fontSize)) {
      updateCellStyle(cell.id, { fontSize });
    }
  };

  const handleFontColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateCellStyle(cell.id, { fontColor: e.target.value });
  };

  const handleBackgroundColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateCellStyle(cell.id, { backgroundColor: e.target.value });
  };

  const handleBorderStyleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const style = e.target.value as 'solid' | 'dashed' | 'none';
    updateCellStyle(cell.id, { 
      borderStyle: style,
      borderWidth: style === 'none' ? 0 : cell.borderWidth || 1
    });
  };

  const handleBorderColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateCellStyle(cell.id, { borderColor: e.target.value });
  };

  const handleBorderWidthChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const width = parseInt(e.target.value);
    if (!isNaN(width)) {
      updateCellStyle(cell.id, { 
        borderWidth: width,
        borderStyle: width === 0 ? 'none' : cell.borderStyle || 'solid'
      });
    }
  };

  const handleTextAlignChange = (align: 'left' | 'center' | 'right') => {
    updateCellStyle(cell.id, { textAlign: align });
  };

  const handleVerticalAlignChange = (align: 'top' | 'middle' | 'bottom') => {
    updateCellStyle(cell.id, { verticalAlign: align });
  };

  const handleMerge = () => {
    if (selectedCells.length > 1) {
      onMerge(selectedCells);
    }
  };

  const handleSplit = () => {
    if (cell.merged) {
      onSplit(selectedCells);
    }
  };

  return (
    <div className="fixed right-4 top-4 w-64 bg-white border rounded-lg shadow-lg p-4">
      <h3 className="text-lg font-semibold mb-4">셀 스타일</h3>

      {/* 병합/분할 버튼 */}
      <div className="mb-4 flex gap-2">
        <button
          onClick={handleMerge}
          disabled={selectedCells.length <= 1}
          className="flex-1 px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
        >
          병합
        </button>
        <button
          onClick={handleSplit}
          disabled={!cell.merged}
          className="flex-1 px-3 py-1 bg-gray-500 text-white rounded hover:bg-gray-600 disabled:opacity-50"
        >
          분할
        </button>
      </div>

      <div className="space-y-4">
        {/* 테두리 스타일 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            테두리 스타일
          </label>
          <select
            value={cell.borderStyle}
            onChange={handleBorderStyleChange}
            className="w-full px-2 py-1 border rounded mb-2"
          >
            <option value="solid">실선</option>
            <option value="dashed">점선</option>
            <option value="none">없음</option>
          </select>
        </div>

        {/* 테두리 두께 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            테두리 두께
          </label>
          <select
            value={cell.borderWidth}
            onChange={handleBorderWidthChange}
            className="w-full px-2 py-1 border rounded mb-2"
          >
            <option value="0">없음</option>
            <option value="1">1px</option>
            <option value="2">2px</option>
            <option value="3">3px</option>
            <option value="4">4px</option>
          </select>
        </div>

        {/* 테두리 색상 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            테두리 색상
          </label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={cell.borderColor}
              onChange={handleBorderColorChange}
              className="w-8 h-8 p-0 border-0"
            />
            <input
              type="text"
              value={cell.borderColor}
              onChange={handleBorderColorChange}
              className="flex-1 px-2 py-1 border rounded"
            />
          </div>
        </div>

        {/* 텍스트 정렬 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            텍스트 정렬
          </label>
          <div className="flex gap-2">
            <button
              onClick={() => handleTextAlignChange('left')}
              className={`flex-1 px-2 py-1 border rounded ${
                cell.textAlign === 'left' ? 'bg-blue-100 border-blue-500' : ''
              }`}
            >
              왼쪽
            </button>
            <button
              onClick={() => handleTextAlignChange('center')}
              className={`flex-1 px-2 py-1 border rounded ${
                cell.textAlign === 'center' ? 'bg-blue-100 border-blue-500' : ''
              }`}
            >
              가운데
            </button>
            <button
              onClick={() => handleTextAlignChange('right')}
              className={`flex-1 px-2 py-1 border rounded ${
                cell.textAlign === 'right' ? 'bg-blue-100 border-blue-500' : ''
              }`}
            >
              오른쪽
            </button>
          </div>
        </div>

        {/* 수직 정렬 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            수직 정렬
          </label>
          <div className="flex gap-2">
            <button
              onClick={() => handleVerticalAlignChange('top')}
              className={`flex-1 px-2 py-1 border rounded ${
                cell.verticalAlign === 'top' ? 'bg-blue-100 border-blue-500' : ''
              }`}
            >
              위
            </button>
            <button
              onClick={() => handleVerticalAlignChange('middle')}
              className={`flex-1 px-2 py-1 border rounded ${
                cell.verticalAlign === 'middle' ? 'bg-blue-100 border-blue-500' : ''
              }`}
            >
              가운데
            </button>
            <button
              onClick={() => handleVerticalAlignChange('bottom')}
              className={`flex-1 px-2 py-1 border rounded ${
                cell.verticalAlign === 'bottom' ? 'bg-blue-100 border-blue-500' : ''
              }`}
            >
              아래
            </button>
          </div>
        </div>

        {/* 폰트 크기 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            폰트 크기
          </label>
          <input
            type="number"
            value={cell.fontSize}
            onChange={handleFontSizeChange}
            min="8"
            max="32"
            className="w-full px-2 py-1 border rounded"
          />
        </div>

        {/* 폰트 색상 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            폰트 색상
          </label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={cell.fontColor}
              onChange={handleFontColorChange}
              className="w-8 h-8 p-0 border-0"
            />
            <input
              type="text"
              value={cell.fontColor}
              onChange={handleFontColorChange}
              className="flex-1 px-2 py-1 border rounded"
            />
          </div>
        </div>

        {/* 배경색 */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            배경색
          </label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={cell.backgroundColor}
              onChange={handleBackgroundColorChange}
              className="w-8 h-8 p-0 border-0"
            />
            <input
              type="text"
              value={cell.backgroundColor}
              onChange={handleBackgroundColorChange}
              className="flex-1 px-2 py-1 border rounded"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FixedGridStylePanel; 