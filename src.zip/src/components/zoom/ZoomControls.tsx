import React from 'react';

interface ZoomControlsProps {
  zoom: number;
  onZoomChange: (zoom: number) => void;
}

const ZoomControls: React.FC<ZoomControlsProps> = ({ zoom, onZoomChange }) => {
  const handleZoomIn = () => {
    const newZoom = Math.min(zoom + 0.1, 2.0);
    onZoomChange(newZoom);
  };

  const handleZoomOut = () => {
    const newZoom = Math.max(zoom - 0.1, 0.5);
    onZoomChange(newZoom);
  };

  const handleReset = () => {
    onZoomChange(1.0);
  };

  return (
    <div className="fixed bottom-4 right-4 flex items-center gap-2 bg-white rounded-lg shadow-lg p-2">
      <button
        onClick={handleZoomOut}
        className="p-2 rounded hover:bg-gray-100"
        title="축소"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
        </svg>
      </button>
      <button
        onClick={handleReset}
        className="px-3 py-1 rounded hover:bg-gray-100"
        title="100%로 초기화"
      >
        {Math.round(zoom * 100)}%
      </button>
      <button
        onClick={handleZoomIn}
        className="p-2 rounded hover:bg-gray-100"
        title="확대"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
      </button>
    </div>
  );
};

export default ZoomControls; 