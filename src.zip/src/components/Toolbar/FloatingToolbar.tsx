import React from 'react';
import { Tool } from '../../types/tool';

interface FloatingToolbarProps {
  currentTool: Tool;
  onToolChange: (tool: Tool) => void;
  onTTCreate: () => void;
}

const FloatingToolbar: React.FC<FloatingToolbarProps> = ({
  currentTool,
  onToolChange,
  onTTCreate,
}) => {
  const getToolButtonClass = (tool: Tool) => {
    const baseClass = 'p-2 rounded-lg transition-all duration-200';
    const activeClass = 'bg-blue-100 text-blue-600 shadow-md scale-110';
    const inactiveClass = 'hover:bg-gray-100';

    return `${baseClass} ${currentTool === tool ? activeClass : inactiveClass}`;
  };

  return (
    <div className="fixed bottom-4 right-4 flex flex-col gap-2 bg-white rounded-lg shadow-lg p-2">
      <button
        onClick={() => onToolChange('pen')}
        className={getToolButtonClass('pen')}
        title="펜"
      >
        ✏️
      </button>
      <button
        onClick={() => onToolChange('eraser')}
        className={getToolButtonClass('eraser')}
        title="지우개"
      >
        🧽
      </button>
      <button
        onClick={onTTCreate}
        className={`p-2 rounded-lg hover:bg-gray-100 transition-all duration-200 ${
          currentTool === 'checkboxText' ? 'bg-blue-100 text-blue-600 shadow-md scale-110' : ''
        }`}
        title="T/T 추가"
      >
        🆕
      </button>
    </div>
  );
};

export default FloatingToolbar; 