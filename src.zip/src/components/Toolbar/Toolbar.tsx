import React from 'react';
import ExcelPasteButton from './ExcelPasteButton';

interface ToolbarProps {
  isViewPage: boolean;
}

const Toolbar: React.FC<ToolbarProps> = ({ isViewPage }) => {
  if (isViewPage) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-white border rounded-lg shadow-lg p-2 flex items-center gap-2 z-50">
      <ExcelPasteButton />
    </div>
  );
};

export default Toolbar; 