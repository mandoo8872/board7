import React, { useState } from 'react';
import { Tool } from '../../types/tool';
import ToolSettingsModal from '../modals/ToolSettingsModal';
import { useToolSettings } from '../../hooks/useToolSettings';

interface AdminToolbarProps {
  currentTool: Tool;
  onToolChange: (tool: Tool) => void;
  onColorChange: (color: string) => void;
  onStrokeWidthChange: (width: number) => void;
  onGridToggle: () => void;
  onGridSizeChange: (size: number) => void;
  onUndo: () => void;
  onRedo: () => void;
  onExport: () => void;
  onImport: () => void;
  onExcelPaste: () => void;
  onImageUpload: (file: File) => void;
  canUndo: boolean;
  canRedo: boolean;
  gridVisible: boolean;
  gridSize: number;
  strokeWidth: number;
  strokeColor: string;
}

const AdminToolbar: React.FC<AdminToolbarProps> = ({
  currentTool,
  onToolChange,
  onColorChange,
  onStrokeWidthChange,
  onGridToggle,
  onGridSizeChange,
  onUndo,
  onRedo,
  onExport,
  onImport,
  onExcelPaste,
  onImageUpload,
  canUndo,
  canRedo,
  gridVisible,
  gridSize,
  strokeWidth,
  strokeColor,
}) => {
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const { settings, updateSettings } = useToolSettings('admin');

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImageUpload(file);
    }
  };

  const getToolButtonClass = (tool: Tool) => {
    const baseClass = 'p-2 rounded-lg transition-all duration-200';
    const activeClass = 'bg-blue-100 text-blue-600 shadow-md scale-110';
    const inactiveClass = 'hover:bg-gray-100';

    return `${baseClass} ${currentTool === tool ? activeClass : inactiveClass}`;
  };

  return (
    <>
      <div className="fixed top-0 left-0 right-0 h-12 bg-white border-b shadow-sm z-50">
        <div className="h-full flex items-center px-4 gap-4">
          {/* 그리기 도구 */}
          <div className="flex items-center gap-2 border-r pr-4">
            <button
              onClick={() => onToolChange('select')}
              className={getToolButtonClass('select')}
              title="선택"
            >
              👆
            </button>
            <button
              onClick={() => onToolChange('pen')}
              className={getToolButtonClass('pen')}
              title="펜"
            >
              ✏️
            </button>
            <button
              onClick={() => onToolChange('eraser')}
              className={getToolButtonClass('eraser')}
              title="지우개"
            >
              🧽
            </button>
            <button
              onClick={() => onToolChange('text')}
              className={getToolButtonClass('text')}
              title="텍스트"
            >
              T
            </button>
            <button
              onClick={() => onToolChange('rectangle')}
              className={getToolButtonClass('rectangle')}
              title="사각형"
            >
              ⬜
            </button>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 rounded-lg hover:bg-gray-100 transition-all duration-200"
              title="설정"
            >
              ⚙️
            </button>
          </div>

          {/* 펜 설정 */}
          <div className="flex items-center gap-2 border-r pr-4">
            <div className="relative">
              <button
                onClick={() => setShowColorPicker(!showColorPicker)}
                className="w-8 h-8 rounded border"
                style={{ backgroundColor: strokeColor }}
                title="색상 선택"
              />
              {showColorPicker && (
                <div className="absolute top-full left-0 mt-2 p-2 bg-white border rounded shadow-lg">
                  <input
                    type="color"
                    value={strokeColor}
                    onChange={(e) => onColorChange(e.target.value)}
                    className="w-32 h-8"
                  />
                  <input
                    type="text"
                    value={strokeColor}
                    onChange={(e) => onColorChange(e.target.value)}
                    className="w-32 mt-2 px-2 py-1 border rounded"
                  />
                </div>
              )}
            </div>
            <input
              type="range"
              min="1"
              max="20"
              value={strokeWidth}
              onChange={(e) => onStrokeWidthChange(parseInt(e.target.value))}
              className="w-24"
              title="선 두께"
            />
            <span className="text-sm text-gray-600">{strokeWidth}px</span>
          </div>

          {/* 외부 객체 */}
          <div className="flex items-center gap-2 border-r pr-4">
            <button
              onClick={onExcelPaste}
              className="p-2 rounded hover:bg-gray-100"
              title="엑셀 붙여넣기"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </button>
            <label className="p-2 rounded hover:bg-gray-100 cursor-pointer" title="이미지 업로드">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </label>
          </div>

          {/* 명령어 */}
          <div className="flex items-center gap-2 border-r pr-4">
            <button
              onClick={onUndo}
              disabled={!canUndo}
              className={`p-2 rounded ${
                canUndo ? 'hover:bg-gray-100' : 'opacity-50 cursor-not-allowed'
              }`}
              title="실행 취소"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
              </svg>
            </button>
            <button
              onClick={onRedo}
              disabled={!canRedo}
              className={`p-2 rounded ${
                canRedo ? 'hover:bg-gray-100' : 'opacity-50 cursor-not-allowed'
              }`}
              title="다시 실행"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 10H11a8 8 0 00-8 8v2M21 10l-6 6m6-6l-6-6" />
              </svg>
            </button>
            <button
              onClick={onExport}
              className="p-2 rounded hover:bg-gray-100"
              title="보드 저장"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
              </svg>
            </button>
            <button
              onClick={onImport}
              className="p-2 rounded hover:bg-gray-100"
              title="보드 불러오기"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
            </button>
          </div>

          {/* 그리드 설정 */}
          <div className="flex items-center gap-2">
            <button
              onClick={onGridToggle}
              className={`p-2 rounded ${
                gridVisible ? 'bg-blue-100' : 'hover:bg-gray-100'
              }`}
              title="그리드 표시"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
            </button>
            <input
              type="range"
              min="16"
              max="200"
              step="8"
              value={gridSize}
              onChange={(e) => onGridSizeChange(parseInt(e.target.value))}
              className="w-24"
              title="그리드 간격"
            />
            <span className="text-sm text-gray-600">{gridSize}px</span>
          </div>
        </div>
      </div>

      <ToolSettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        settings={settings}
        onSettingsChange={updateSettings}
      />
    </>
  );
};

export default AdminToolbar; 