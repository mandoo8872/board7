import React, { useRef, useEffect, useCallback } from 'react';
import { CanvasProps } from '../types';
import { useStore } from '../store/useStore';

const Canvas: React.FC<CanvasProps> = ({ isViewPage }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const {
    currentTool,
    isDrawing,
    setIsDrawing,
    strokes,
    addStroke,
    scale,
    showGrid,
    gridSize,
  } = useStore();

  // 캔버스 크기 설정
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      redrawCanvas();
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  // 캔버스 그리기
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 캔버스 초기화
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 그리드 그리기
    if (showGrid) {
      ctx.strokeStyle = '#e5e7eb';
      ctx.lineWidth = 1;
      
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }
    }

    // 스트로크 그리기
    ctx.save();
    ctx.scale(scale, scale);
    
    strokes.forEach((stroke) => {
      ctx.beginPath();
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      
      stroke.path.forEach((point, index) => {
        if (index === 0) {
          ctx.moveTo(point[0], point[1]);
        } else {
          ctx.lineTo(point[0], point[1]);
        }
      });
      
      ctx.stroke();
    });
    
    ctx.restore();
  }, [strokes, scale, showGrid, gridSize]);

  // 그리기 이벤트 핸들러
  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    if (currentTool !== 'pen' && currentTool !== 'eraser') return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / scale;
    const y = (e.clientY - rect.top) / scale;

    setIsDrawing(true);
    addStroke({
      path: [[x, y]],
      color: currentTool === 'pen' ? '#000000' : '#ffffff',
      width: currentTool === 'pen' ? 2 : 20,
    });
  }, [currentTool, scale, setIsDrawing, addStroke]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDrawing || (currentTool !== 'pen' && currentTool !== 'eraser')) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / scale;
    const y = (e.clientY - rect.top) / scale;

    const lastStroke = strokes[strokes.length - 1];
    if (lastStroke) {
      lastStroke.path.push([x, y]);
      redrawCanvas();
    }
  }, [isDrawing, currentTool, scale, strokes, redrawCanvas]);

  const handlePointerUp = useCallback(() => {
    setIsDrawing(false);
  }, [setIsDrawing]);

  // 캔버스 업데이트 시 다시 그리기
  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute top-0 left-0 w-full h-full"
      style={{ touchAction: 'none' }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
    />
  );
};

export default Canvas; 