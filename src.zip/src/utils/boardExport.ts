import { ref, get, set } from 'firebase/database';
import { database } from './firebase';

export interface BoardData {
  shapes: Record<string, any>;
  strokes: Record<string, any>;
  fixedCells: Record<string, any>;
}

export const exportBoardData = async (): Promise<BoardData> => {
  try {
    const shapesRef = ref(database, 'sharedBoardData/shapes');
    const strokesRef = ref(database, 'sharedBoardData/strokes');
    const fixedCellsRef = ref(database, 'sharedBoardData/fixedCells');

    const [shapesSnapshot, strokesSnapshot, fixedCellsSnapshot] = await Promise.all([
      get(shapesRef),
      get(strokesRef),
      get(fixedCellsRef),
    ]);

    const boardData: BoardData = {
      shapes: shapesSnapshot.val() || {},
      strokes: strokesSnapshot.val() || {},
      fixedCells: fixedCellsSnapshot.val() || {},
    };

    return boardData;
  } catch (error) {
    console.error('보드 데이터 내보내기 실패:', error);
    throw error;
  }
};

export const importBoardData = async (data: BoardData): Promise<void> => {
  try {
    const shapesRef = ref(database, 'sharedBoardData/shapes');
    const strokesRef = ref(database, 'sharedBoardData/strokes');
    const fixedCellsRef = ref(database, 'sharedBoardData/fixedCells');

    await Promise.all([
      set(shapesRef, data.shapes),
      set(strokesRef, data.strokes),
      set(fixedCellsRef, data.fixedCells),
    ]);
  } catch (error) {
    console.error('보드 데이터 가져오기 실패:', error);
    throw error;
  }
};

export const downloadBoardData = (data: BoardData): void => {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `board7-backup-${timestamp}.json`;
  const jsonString = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const validateBoardData = (data: any): boolean => {
  if (!data || typeof data !== 'object') return false;
  if (!('shapes' in data) || !('strokes' in data) || !('fixedCells' in data)) return false;
  return true;
}; 