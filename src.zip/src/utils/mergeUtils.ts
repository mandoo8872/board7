import { FixedGridCell } from '../types/fixedGrid';

export const mergeCells = (cells: FixedGridCell[]): FixedGridCell[] => {
  if (cells.length <= 1) return cells;

  // 선택된 셀들의 위치 정보 추출
  const positions = cells.map(cell => {
    const match = cell.id.match(/cell-r(\d+)-c(\d+)/);
    if (!match) return null;
    return {
      cell,
      row: parseInt(match[1]),
      col: parseInt(match[2]),
    };
  }).filter((pos): pos is NonNullable<typeof pos> => pos !== null);

  if (positions.length <= 1) return cells;

  // 가장 좌상단 셀을 루트로 지정
  const rootCell = positions.reduce((min, pos) => {
    if (pos.row < min.row || (pos.row === min.row && pos.col < min.col)) {
      return pos;
    }
    return min;
  });

  // 병합된 영역의 크기 계산
  const rowspan = Math.max(...positions.map(p => p.row)) - rootCell.row + 1;
  const colspan = Math.max(...positions.map(p => p.col)) - rootCell.col + 1;

  // 루트 셀 업데이트
  const updatedRootCell: FixedGridCell = {
    ...rootCell.cell,
    merged: true,
    mergedRoot: rootCell.cell.id,
    rowspan,
    colspan,
    width: rootCell.cell.width * colspan,
    height: rootCell.cell.height * rowspan,
  };

  // 나머지 셀 숨김 처리
  const updatedCells = cells.map(cell => {
    if (cell.id === rootCell.cell.id) {
      return updatedRootCell;
    }
    return {
      ...cell,
      merged: true,
      mergedRoot: rootCell.cell.id,
      rowspan: 1,
      colspan: 1,
    };
  });

  return updatedCells;
};

export const splitCells = (cells: FixedGridCell[]): FixedGridCell[] => {
  // 병합된 셀 그룹 찾기
  const mergedGroups = new Map<string, FixedGridCell[]>();
  cells.forEach(cell => {
    if (cell.merged && cell.mergedRoot) {
      const group = mergedGroups.get(cell.mergedRoot) || [];
      group.push(cell);
      mergedGroups.set(cell.mergedRoot, group);
    }
  });

  // 각 병합 그룹 분할
  const updatedCells = cells.map(cell => {
    if (!cell.merged || !cell.mergedRoot) return cell;

    const group = mergedGroups.get(cell.mergedRoot);
    if (!group) return cell;

    // 원래 크기로 복원
    return {
      ...cell,
      merged: false,
      mergedRoot: null,
      rowspan: 1,
      colspan: 1,
      width: cell.width / (group[0].colspan || 1),
      height: cell.height / (group[0].rowspan || 1),
    };
  });

  return updatedCells;
}; 