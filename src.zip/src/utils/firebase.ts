import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { ref, set, get, onValue, off, push, remove } from 'firebase/database';
import { signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { db, auth } from '../config/firebase';
import { BoardData, UserData, FirebaseError } from '../types/firebase';

const firebaseConfig = {
  apiKey: "AIzaSyA2Ml7QMBlaUyKZyFu7j83I5Y2eM1COgkc",
  authDomain: "board7-4373c.firebaseapp.com",
  databaseURL: "https://board7-4373c-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "board7-4373c",
  storageBucket: "board7-4373c.firebasestorage.app",
  messagingSenderId: "298011654216",
  appId: "1:298011654216:web:084fb0f220aa7be5b4807d"
};

const app = initializeApp(firebaseConfig);
export const database = getDatabase(app); 

// 보드 데이터 저장
export const saveBoardData = async (boardId: string, data: Omit<BoardData, 'id'>): Promise<void> => {
  try {
    const boardRef = ref(db, `boards/${boardId}`);
    await set(boardRef, {
      ...data,
      lastModified: Date.now(),
    });
  } catch (error) {
    console.error('보드 데이터 저장 실패:', error);
    throw new Error('보드 데이터 저장에 실패했습니다.');
  }
};

// 보드 데이터 로드
export const loadBoardData = async (boardId: string): Promise<BoardData> => {
  try {
    const boardRef = ref(db, `boards/${boardId}`);
    const snapshot = await get(boardRef);
    
    if (!snapshot.exists()) {
      throw new Error('보드를 찾을 수 없습니다.');
    }

    return {
      id: boardId,
      ...snapshot.val(),
    };
  } catch (error) {
    console.error('보드 데이터 로드 실패:', error);
    throw new Error('보드 데이터 로드에 실패했습니다.');
  }
};

// 실시간 보드 데이터 구독
export const subscribeToBoard = (
  boardId: string,
  onUpdate: (data: BoardData) => void,
  onError: (error: FirebaseError) => void
): (() => void) => {
  const boardRef = ref(db, `boards/${boardId}`);
  
  onValue(boardRef, (snapshot) => {
    if (snapshot.exists()) {
      onUpdate({
        id: boardId,
        ...snapshot.val(),
      });
    }
  }, (error) => {
    onError({
      code: error.code,
      message: error.message,
    });
  });

  return () => off(boardRef);
};

// 사용자 로그인
export const loginUser = async (email: string, password: string): Promise<UserData> => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // 사용자 데이터 업데이트
    const userRef = ref(db, `users/${user.uid}`);
    const userData: UserData = {
      id: user.uid,
      email: user.email!,
      role: 'viewer', // 기본값은 viewer
      lastLogin: Date.now(),
    };
    
    await set(userRef, userData);
    return userData;
  } catch (error) {
    console.error('로그인 실패:', error);
    throw new Error('로그인에 실패했습니다.');
  }
};

// 사용자 로그아웃
export const logoutUser = async (): Promise<void> => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('로그아웃 실패:', error);
    throw new Error('로그아웃에 실패했습니다.');
  }
};

// 새 보드 생성
export const createBoard = async (userId: string): Promise<string> => {
  try {
    const boardsRef = ref(db, 'boards');
    const newBoardRef = push(boardsRef);
    const boardId = newBoardRef.key!;
    
    const initialData: Omit<BoardData, 'id'> = {
      strokes: [],
      cells: [],
      lastModified: Date.now(),
      createdBy: userId,
    };
    
    await set(newBoardRef, initialData);
    return boardId;
  } catch (error) {
    console.error('보드 생성 실패:', error);
    throw new Error('보드 생성에 실패했습니다.');
  }
};

// 보드 삭제
export const deleteBoard = async (boardId: string): Promise<void> => {
  try {
    const boardRef = ref(db, `boards/${boardId}`);
    await remove(boardRef);
  } catch (error) {
    console.error('보드 삭제 실패:', error);
    throw new Error('보드 삭제에 실패했습니다.');
  }
}; 