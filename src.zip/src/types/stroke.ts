export type Stroke = {
  id: string;
  points: number[][]; // [[x, y], [x, y], ...]
  color: string;
  size: number;
  type: 'pen' | 'eraser';
  createdAt: number;
}; 