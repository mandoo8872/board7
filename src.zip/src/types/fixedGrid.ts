export interface FixedGridCell {
  id: string;
  text: string;
  fontSize: number;
  fontColor: string;
  backgroundColor: string;
  borderStyle: 'solid' | 'dashed' | 'none';
  borderWidth: number;
  borderColor: string;
  textAlign: 'left' | 'center' | 'right';
  verticalAlign: 'top' | 'middle' | 'bottom';
  merged: boolean;
  mergedRoot: string | null;
  rowspan: number;
  colspan: number;
}

export interface FixedGridConfig {
  startX: number;
  startY: number;
  cellWidth: number;
  cellHeight: number;
  rows: number;
  cols: number;
}

export interface CellSelection {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
} 