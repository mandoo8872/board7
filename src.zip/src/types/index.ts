export interface BaseObject {
  id: string;
  type: 'box' | 'text' | 'image' | 'checkbox-text' | 'grid-cell';
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  locked: boolean;
  resizable: boolean;
  deletable: boolean;
  selected: boolean;
  updatedAt?: number;
  updatedBy?: string;
}

export interface TextObject extends BaseObject {
  type: 'text';
  text: string;
  fontSize: number;
  textAlign: 'left' | 'center' | 'right';
  textColor: string;
  textOpacity: number;
  backgroundColor: string;
  backgroundOpacity: number;
}

export interface CheckboxTextObject extends BaseObject {
  type: 'checkbox-text';
  text: string;
  checked: boolean;
  fontSize: number;
  textAlign: 'left' | 'center' | 'right';
  textColor: string;
  textOpacity: number;
  backgroundColor: string;
  backgroundOpacity: number;
}

export interface ImageObject extends BaseObject {
  type: 'image';
  src: string;
}

export interface BoxObject extends BaseObject {
  type: 'box';
  backgroundColor: string;
  backgroundOpacity: number;
}

export interface GridCellObject extends BaseObject {
  type: 'grid-cell';
  text: string;
  row: number;
  col: number;
  rowSpan?: number;
  colSpan?: number;
  fontSize: number;
  textAlign: 'left' | 'center' | 'right';
  textColor: string;
  textOpacity: number;
  backgroundColor: string;
  backgroundOpacity: number;
}

export type BoardObject = TextObject | CheckboxTextObject | ImageObject | BoxObject | GridCellObject;

export interface Stroke {
  id: string;
  points: { x: number; y: number }[];
  color: string;
  width: number;
  opacity: number;
}

// 도구 타입 정의
export type Tool = 'select' | 'pen' | 'eraser' | 'text' | 'rectangle';

// 캔버스 관련 타입 정의
export interface CanvasProps {
  isViewPage: boolean;
}

// 스트로크 타입 정의
export interface Stroke {
  path: number[][];
  color: string;
  width: number;
}

// 셀 타입 정의
export interface Cell {
  id: string;
  text: string;
  fontSize: number;
  fontColor: string;
  backgroundColor: string;
  borderStyle: string;
  borderWidth: number;
  borderColor: string;
  textAlign: 'left' | 'center' | 'right';
  verticalAlign: 'top' | 'middle' | 'bottom';
  merged: boolean;
  mergedRoot: string | null;
  rowspan: number;
  colspan: number;
} 