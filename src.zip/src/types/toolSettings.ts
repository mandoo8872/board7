export interface ToolAutoSwitchSettings {
  enabled: boolean;
  timeout: number;
  disableOnTTInput: boolean;
  switchOnMouseStop: boolean;
  syncWithViewPage: boolean;
}

export const DEFAULT_TOOL_SETTINGS: ToolAutoSwitchSettings = {
  enabled: true,
  timeout: 2000,
  disableOnTTInput: true,
  switchOnMouseStop: false,
  syncWithViewPage: false,
};

export type SettingsPage = 'admin' | 'view';

export const STORAGE_KEYS = {
  admin: 'toolAutoSwitch_admin',
  view: 'toolAutoSwitch_view',
} as const; 