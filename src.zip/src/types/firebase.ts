import { Stroke, Cell } from './index';

export interface BoardData {
  id: string;
  strokes: Stroke[];
  cells: Cell[];
  lastModified: number;
  createdBy: string;
}

export interface UserData {
  id: string;
  email: string;
  role: 'admin' | 'viewer';
  lastLogin: number;
}

export interface FirebaseError {
  code: string;
  message: string;
} 