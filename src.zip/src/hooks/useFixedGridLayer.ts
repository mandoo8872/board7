import { useState, useCallback } from 'react';
import { ref, onValue, set } from 'firebase/database';
import { database } from '../config/firebase';
import { FixedGridCell } from '../types/fixedGrid';

export const useFixedGridLayer = () => {
  const [cells, setCells] = useState<FixedGridCell[]>([]);
  const [selectedCells, setSelectedCells] = useState<string[]>([]);
  const [selection, setSelection] = useState<{ startRow: number; startCol: number; endRow: number; endCol: number } | null>(null);
  const [isSelecting, setIsSelecting] = useState(false);

  const getCellPosition = useCallback((cellId: string) => {
    const match = cellId.match(/cell-(\d+)-(\d+)/);
    if (match) {
      return {
        row: parseInt(match[1]),
        col: parseInt(match[2]),
      };
    }
    return null;
  }, []);

  const startSelection = useCallback((cellId: string) => {
    const position = getCellPosition(cellId);
    if (position) {
      setSelection({
        startRow: position.row,
        startCol: position.col,
        endRow: position.row,
        endCol: position.col,
      });
      setIsSelecting(true);
    }
  }, [getCellPosition]);

  const updateSelection = useCallback((cellId: string) => {
    if (!isSelecting || !selection) return;

    const position = getCellPosition(cellId);
    if (position) {
      setSelection({
        ...selection,
        endRow: position.row,
        endCol: position.col,
      });
    }
  }, [isSelecting, selection, getCellPosition]);

  const endSelection = useCallback(() => {
    if (!selection) return;

    const { startRow, startCol, endRow, endCol } = selection;
    const minRow = Math.min(startRow, endRow);
    const maxRow = Math.max(startRow, endRow);
    const minCol = Math.min(startCol, endCol);
    const maxCol = Math.max(startCol, endCol);

    const selectedCellIds: string[] = [];
    for (let row = minRow; row <= maxRow; row++) {
      for (let col = minCol; col <= maxCol; col++) {
        selectedCellIds.push(`cell-${row}-${col}`);
      }
    }

    setSelectedCells(selectedCellIds);
    setIsSelecting(false);
    setSelection(null);
  }, [selection]);

  const clearSelection = useCallback(() => {
    setSelectedCells([]);
    setSelection(null);
    setIsSelecting(false);
  }, []);

  const toggleCellSelection = useCallback((cellId: string) => {
    setSelectedCells(prev => {
      if (prev.includes(cellId)) {
        return prev.filter(id => id !== cellId);
      } else {
        return [...prev, cellId];
      }
    });
  }, []);

  // Firebase에서 셀 데이터 구독
  const cellsRef = ref(database, 'sharedBoardData/fixedCells');
  onValue(cellsRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      const cellsArray = Object.entries(data).map(([id, cell]) => ({
        id,
        ...cell,
      })) as FixedGridCell[];
      setCells(cellsArray);
    }
  });

  return {
    cells,
    selectedCells,
    startSelection,
    updateSelection,
    endSelection,
    clearSelection,
    toggleCellSelection,
  };
}; 