import { useCallback } from 'react';
import { ref, set } from 'firebase/database';
import { db } from '../config/firebase';
import { useStore } from '../store/useStore';

export const useExcelPaste = () => {
  const { addCell } = useStore();

  const handleExcelPaste = useCallback(async (boardId: string, data: string) => {
    try {
      // Excel 데이터 파싱
      const rows = data.split('\n').map(row => row.split('\t'));
      
      // 데이터를 Firebase에 저장
      const boardRef = ref(db, `boards/${boardId}/excelData`);
      await set(boardRef, {
        data: rows,
        timestamp: Date.now()
      });

      // 로컬 상태 업데이트
      rows.forEach((row, rowIndex) => {
        row.forEach((cell, colIndex) => {
          if (cell.trim()) {
            addCell({
              id: `${rowIndex}-${colIndex}`,
              text: cell,
              fontSize: 14,
              fontColor: '#000000',
              backgroundColor: '#ffffff',
              borderStyle: 'solid',
              borderWidth: 1,
              borderColor: '#000000',
              textAlign: 'left',
              verticalAlign: 'top',
              merged: false,
              mergedRoot: null,
              rowspan: 1,
              colspan: 1
            });
          }
        });
      });

      return true;
    } catch (error) {
      console.error('Excel 데이터 붙여넣기 실패:', error);
      return false;
    }
  }, [addCell]);

  return { handleExcelPaste };
}; 