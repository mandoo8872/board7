import { useState, useCallback } from 'react';
import { FixedGridCell, CellSelection } from '../types/fixedGrid';

export const useSelectedCells = () => {
  const [selectedCells, setSelectedCells] = useState<FixedGridCell[]>([]);
  const [selection, setSelection] = useState<CellSelection | null>(null);
  const [isSelecting, setIsSelecting] = useState(false);

  const getCellPosition = useCallback((cellId: string) => {
    const match = cellId.match(/cell-r(\d+)-c(\d+)/);
    if (!match) return null;
    return {
      row: parseInt(match[1]),
      col: parseInt(match[2]),
    };
  }, []);

  const startSelection = useCallback((cell: FixedGridCell) => {
    const pos = getCellPosition(cell.id);
    if (!pos) return;

    setSelection({
      startRow: pos.row,
      startCol: pos.col,
      endRow: pos.row,
      endCol: pos.col,
    });
    setIsSelecting(true);
    setSelectedCells([cell]);
  }, [getCellPosition]);

  const updateSelection = useCallback((cell: FixedGridCell) => {
    if (!isSelecting || !selection) return;

    const pos = getCellPosition(cell.id);
    if (!pos) return;

    setSelection({
      ...selection,
      endRow: pos.row,
      endCol: pos.col,
    });
  }, [isSelecting, selection, getCellPosition]);

  const endSelection = useCallback((cells: FixedGridCell[]) => {
    if (!selection) return;

    const startRow = Math.min(selection.startRow, selection.endRow);
    const endRow = Math.max(selection.startRow, selection.endRow);
    const startCol = Math.min(selection.startCol, selection.endCol);
    const endCol = Math.max(selection.startCol, selection.endCol);

    const selectedCells = cells.filter(cell => {
      const pos = getCellPosition(cell.id);
      if (!pos) return false;

      return pos.row >= startRow && pos.row <= endRow &&
             pos.col >= startCol && pos.col <= endCol;
    });

    setSelectedCells(selectedCells);
    setIsSelecting(false);
  }, [selection, getCellPosition]);

  const clearSelection = useCallback(() => {
    setSelectedCells([]);
    setSelection(null);
    setIsSelecting(false);
  }, []);

  const toggleCellSelection = useCallback((cell: FixedGridCell) => {
    setSelectedCells(prev => {
      const isSelected = prev.some(c => c.id === cell.id);
      if (isSelected) {
        return prev.filter(c => c.id !== cell.id);
      } else {
        return [...prev, cell];
      }
    });
  }, []);

  return {
    selectedCells,
    isSelecting,
    startSelection,
    updateSelection,
    endSelection,
    clearSelection,
    toggleCellSelection,
  };
}; 