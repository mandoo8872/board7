import { useState, useCallback } from 'react';
import { ref, onValue, set } from 'firebase/database';
import { database } from '../config/firebase';

export const useBackgroundImage = () => {
  const [backgroundImage, setBackgroundImage] = useState<string | null>(null);

  // Firebase에서 배경 이미지 데이터 구독
  const backgroundImageRef = ref(database, 'sharedBoardData/backgroundImage');
  onValue(backgroundImageRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      setBackgroundImage(data);
    }
  });

  const updateBackgroundImage = useCallback(async (imageUrl: string) => {
    try {
      await set(backgroundImageRef, imageUrl);
    } catch (error) {
      console.error('배경 이미지 업데이트 실패:', error);
    }
  }, []);

  return {
    backgroundImage,
    setBackgroundImage: updateBackgroundImage,
  };
}; 