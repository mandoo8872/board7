import { useState, useEffect, useCallback } from 'react';
import {
  ToolAutoSwitchSettings,
  DEFAULT_TOOL_SETTINGS,
  SettingsPage,
  STORAGE_KEYS,
} from '../types/toolSettings';

export const useToolSettings = (page: SettingsPage) => {
  const [settings, setSettings] = useState<ToolAutoSwitchSettings>(DEFAULT_TOOL_SETTINGS);

  // 설정 로드
  const loadSettings = useCallback(() => {
    const storedSettings = localStorage.getItem(STORAGE_KEYS[page]);
    if (storedSettings) {
      try {
        const parsedSettings = JSON.parse(storedSettings);
        setSettings(parsedSettings);
      } catch (error) {
        console.error('설정 로드 실패:', error);
        setSettings(DEFAULT_TOOL_SETTINGS);
      }
    }
  }, [page]);

  // 설정 저장
  const saveSettings = useCallback((newSettings: ToolAutoSwitchSettings) => {
    try {
      localStorage.setItem(STORAGE_KEYS[page], JSON.stringify(newSettings));
      setSettings(newSettings);

      // ViewPage와 설정 연동이 활성화된 경우 ViewPage 설정도 업데이트
      if (page === 'admin' && newSettings.syncWithViewPage) {
        localStorage.setItem(STORAGE_KEYS.view, JSON.stringify(newSettings));
      }
    } catch (error) {
      console.error('설정 저장 실패:', error);
    }
  }, [page]);

  // 설정 업데이트
  const updateSettings = useCallback((updates: Partial<ToolAutoSwitchSettings>) => {
    const newSettings = { ...settings, ...updates };
    saveSettings(newSettings);
  }, [settings, saveSettings]);

  // 초기 설정 로드
  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  return {
    settings,
    updateSettings,
    resetSettings: () => saveSettings(DEFAULT_TOOL_SETTINGS),
  };
}; 