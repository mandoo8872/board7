import { useState, useCallback, useEffect } from 'react';
import { ref, push, update, onValue } from 'firebase/database';
import { database } from '../utils/firebase';
import { FixedGridCell, FixedGridConfig } from '../types/fixedGrid';

const GRID_CONFIG: FixedGridConfig = {
  startX: 60,
  startY: 150,
  cellWidth: 170,
  cellHeight: 36,
  rows: 20,
  cols: 10,
};

export const useFixedGrid = (isViewPage: boolean) => {
  const [cells, setCells] = useState<FixedGridCell[]>([]);

  // Firebase에서 cells 구독
  useEffect(() => {
    const cellsRef = ref(database, 'sharedBoardData/fixedCells');
    const unsubscribe = onValue(cellsRef, (snapshot) => {
      const cells: FixedGridCell[] = [];
      snapshot.forEach((childSnapshot) => {
        cells.push(childSnapshot.val());
      });
      setCells(cells);
    });

    return () => unsubscribe();
  }, []);

  // 엑셀 데이터 파싱 및 셀 생성
  const parseExcelData = useCallback(async (excelData: string) => {
    if (isViewPage) return;

    const rows = excelData.split('\n');
    const newCells: FixedGridCell[] = [];

    rows.forEach((row, rowIndex) => {
      if (rowIndex >= GRID_CONFIG.rows) return;

      const cols = row.split('\t');
      cols.forEach((text, colIndex) => {
        if (colIndex >= GRID_CONFIG.cols) return;

        const x = GRID_CONFIG.startX + colIndex * GRID_CONFIG.cellWidth;
        const y = GRID_CONFIG.startY + rowIndex * GRID_CONFIG.cellHeight;

        newCells.push({
          id: push(ref(database, 'sharedBoardData/fixedCells')).key!,
          x,
          y,
          width: GRID_CONFIG.cellWidth,
          height: GRID_CONFIG.cellHeight,
          text: text.trim(),
          fontSize: 14,
          textAlign: 'center',
          updatedAt: Date.now(),
        });
      });
    });

    // Firebase에 셀 데이터 업로드
    const updates: { [key: string]: FixedGridCell } = {};
    newCells.forEach(cell => {
      updates[`sharedBoardData/fixedCells/${cell.id}`] = cell;
    });
    await update(ref(database), updates);
  }, [isViewPage]);

  // 셀 텍스트 업데이트
  const updateCellText = useCallback(async (cellId: string, text: string) => {
    if (isViewPage) return;

    const cellRef = ref(database, `sharedBoardData/fixedCells/${cellId}`);
    await update(cellRef, {
      text,
      updatedAt: Date.now(),
    });
  }, [isViewPage]);

  return {
    cells,
    parseExcelData,
    updateCellText,
    config: GRID_CONFIG,
  };
}; 