import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth } from '../config/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import {
  saveBoardData,
  loadBoardData,
  subscribeToBoard,
  loginUser,
  logoutUser,
  createBoard,
  deleteBoard,
} from '../utils/firebase';
import { BoardData, UserData, FirebaseError } from '../types/firebase';

export const useFirebase = () => {
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  // 인증 상태 변경 감지
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userData: UserData = {
            id: firebaseUser.uid,
            email: firebaseUser.email!,
            role: 'viewer', // 기본값
            lastLogin: Date.now(),
          };
          setUser(userData);
        } catch (err) {
          setError('사용자 정보를 가져오는데 실패했습니다.');
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // 로그인
  const login = useCallback(async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);
      const userData = await loginUser(email, password);
      setUser(userData);
      navigate('/admin');
    } catch (err) {
      setError('로그인에 실패했습니다.');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  // 로그아웃
  const logout = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      await logoutUser();
      setUser(null);
      navigate('/');
    } catch (err) {
      setError('로그아웃에 실패했습니다.');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  // 보드 데이터 저장
  const saveBoard = useCallback(async (boardId: string, data: Omit<BoardData, 'id'>) => {
    try {
      setError(null);
      await saveBoardData(boardId, data);
    } catch (err) {
      setError('보드 저장에 실패했습니다.');
      throw err;
    }
  }, []);

  // 보드 데이터 로드
  const loadBoard = useCallback(async (boardId: string) => {
    try {
      setLoading(true);
      setError(null);
      const data = await loadBoardData(boardId);
      return data;
    } catch (err) {
      setError('보드 로드에 실패했습니다.');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // 보드 구독
  const subscribeBoard = useCallback((boardId: string, onUpdate: (data: BoardData) => void) => {
    try {
      setError(null);
      return subscribeToBoard(
        boardId,
        onUpdate,
        (error: FirebaseError) => {
          setError(error.message);
        }
      );
    } catch (err) {
      setError('보드 구독에 실패했습니다.');
      throw err;
    }
  }, []);

  // 새 보드 생성
  const createNewBoard = useCallback(async () => {
    if (!user) throw new Error('로그인이 필요합니다.');
    
    try {
      setLoading(true);
      setError(null);
      const boardId = await createBoard(user.id);
      return boardId;
    } catch (err) {
      setError('보드 생성에 실패했습니다.');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [user]);

  // 보드 삭제
  const removeBoard = useCallback(async (boardId: string) => {
    try {
      setLoading(true);
      setError(null);
      await deleteBoard(boardId);
    } catch (err) {
      setError('보드 삭제에 실패했습니다.');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    user,
    loading,
    error,
    login,
    logout,
    saveBoard,
    loadBoard,
    subscribeBoard,
    createNewBoard,
    removeBoard,
  };
}; 