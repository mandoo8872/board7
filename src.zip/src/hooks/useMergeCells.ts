import { useCallback } from 'react';
import { ref, get, set } from 'firebase/database';
import { database } from '../config/firebase';
import { FixedGridCell } from '../types/fixedGrid';

export const useMergeCells = () => {
  const mergeCells = useCallback(async (selectedCellIds: string[]) => {
    try {
      const cellsRef = ref(database, 'sharedBoardData/fixedCells');
      const snapshot = await get(cellsRef);
      const cells = snapshot.val() || {};

      // 선택된 셀들의 위치 정보 추출
      const positions = selectedCellIds.map(id => {
        const match = id.match(/cell-(\d+)-(\d+)/);
        if (match) {
          return {
            id,
            row: parseInt(match[1]),
            col: parseInt(match[2]),
          };
        }
        return null;
      }).filter(Boolean);

      if (positions.length < 2) return;

      // 루트 셀 결정 (가장 작은 행과 열)
      const rootCell = positions.reduce((min, pos) => {
        if (!min || (pos.row < min.row) || (pos.row === min.row && pos.col < min.col)) {
          return pos;
        }
        return min;
      });

      if (!rootCell) return;

      // 병합 영역의 크기 계산
      const maxRow = Math.max(...positions.map(p => p.row));
      const maxCol = Math.max(...positions.map(p => p.col));
      const rowspan = maxRow - rootCell.row + 1;
      const colspan = maxCol - rootCell.col + 1;

      // 루트 셀 업데이트
      const updatedCells = { ...cells };
      updatedCells[rootCell.id] = {
        ...updatedCells[rootCell.id],
        merged: true,
        mergedRoot: rootCell.id,
        rowspan,
        colspan,
      };

      // 다른 셀들 숨김 처리
      positions.forEach(pos => {
        if (pos.id !== rootCell.id) {
          updatedCells[pos.id] = {
            ...updatedCells[pos.id],
            merged: true,
            mergedRoot: rootCell.id,
          };
        }
      });

      // Firebase 업데이트
      await set(cellsRef, updatedCells);
    } catch (error) {
      console.error('셀 병합 실패:', error);
    }
  }, []);

  return { mergeCells };
}; 