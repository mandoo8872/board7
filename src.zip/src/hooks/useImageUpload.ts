import { useCallback } from 'react';
import { ref, set } from 'firebase/database';
import { database } from '../config/firebase';

export const useImageUpload = () => {
  const handleImageUpload = useCallback(async (file: File) => {
    try {
      // 파일을 base64로 변환
      const reader = new FileReader();
      reader.readAsDataURL(file);
      
      reader.onload = async () => {
        const base64 = reader.result as string;
        
        // Firebase에 이미지 데이터 저장
        const backgroundImageRef = ref(database, 'sharedBoardData/backgroundImage');
        await set(backgroundImageRef, base64);
      };
    } catch (error) {
      console.error('이미지 업로드 실패:', error);
    }
  }, []);

  return { handleImageUpload };
}; 