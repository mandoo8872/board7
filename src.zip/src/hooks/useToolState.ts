import { useState, useCallback, useRef, useEffect } from 'react';
import { Tool } from '../types/tool';
import { useToolSettings } from './useToolSettings';
import { SettingsPage } from '../types/toolSettings';

interface UseToolStateProps {
  isViewPage: boolean;
  onToolChange?: (tool: Tool) => void;
}

export const useToolState = ({ isViewPage, onToolChange }: UseToolStateProps) => {
  const [currentTool, setCurrentTool] = useState<Tool>('select');
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);
  const autoSwitchTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isDraggingRef = useRef(false);
  const lastInteractionTimeRef = useRef<number>(Date.now());
  const { settings } = useToolSettings(isViewPage ? 'view' : 'admin');

  // 자동 전환 타이머 설정
  const startAutoSwitchTimer = useCallback(() => {
    if (autoSwitchTimerRef.current) {
      clearTimeout(autoSwitchTimerRef.current);
    }

    // 설정이 비활성화되었거나 키보드가 열려있으면 타이머 시작하지 않음
    if (!settings.enabled || isKeyboardOpen) {
      return;
    }

    // 펜이나 지우개 도구일 때만 자동 전환 타이머 시작
    if ((currentTool === 'pen' || currentTool === 'eraser')) {
      autoSwitchTimerRef.current = setTimeout(() => {
        const now = Date.now();
        const timeSinceLastInteraction = now - lastInteractionTimeRef.current;

        // 마지막 상호작용 후 설정된 시간이 지났고, 드래그 중이 아닐 때만 전환
        if (timeSinceLastInteraction >= settings.timeout && !isDraggingRef.current) {
          setCurrentTool('select');
          onToolChange?.('select');
        }
      }, settings.timeout);
    }
  }, [currentTool, isKeyboardOpen, onToolChange, settings]);

  // 상호작용 시간 업데이트
  const updateLastInteractionTime = useCallback(() => {
    lastInteractionTimeRef.current = Date.now();
    if (settings.switchOnMouseStop) {
      startAutoSwitchTimer();
    }
  }, [startAutoSwitchTimer, settings.switchOnMouseStop]);

  // 드래그 시작
  const handleDragStart = useCallback(() => {
    isDraggingRef.current = true;
    if (autoSwitchTimerRef.current) {
      clearTimeout(autoSwitchTimerRef.current);
    }
  }, []);

  // 드래그 종료
  const handleDragEnd = useCallback(() => {
    isDraggingRef.current = false;
    updateLastInteractionTime();
  }, [updateLastInteractionTime]);

  // 도구 변경
  const handleToolChange = useCallback((tool: Tool) => {
    if (autoSwitchTimerRef.current) {
      clearTimeout(autoSwitchTimerRef.current);
    }

    setCurrentTool(tool);
    onToolChange?.(tool);
    updateLastInteractionTime();

    // 텍스트나 T/T 도구는 자동 전환 타이머 시작하지 않음
    if (tool !== 'text' && tool !== 'checkboxText') {
      startAutoSwitchTimer();
    }
  }, [onToolChange, startAutoSwitchTimer, updateLastInteractionTime]);

  // 키보드 열기
  const handleKeyboardOpen = useCallback(() => {
    setIsKeyboardOpen(true);
    if (autoSwitchTimerRef.current) {
      clearTimeout(autoSwitchTimerRef.current);
    }
  }, []);

  // 키보드 닫기
  const handleKeyboardClose = useCallback(() => {
    setIsKeyboardOpen(false);
    if (currentTool === 'text' || currentTool === 'checkboxText') {
      setCurrentTool('select');
      onToolChange?.('select');
    }
  }, [currentTool, onToolChange]);

  // 컴포넌트 언마운트 시 타이머 정리
  useEffect(() => {
    return () => {
      if (autoSwitchTimerRef.current) {
        clearTimeout(autoSwitchTimerRef.current);
      }
    };
  }, []);

  return {
    currentTool,
    isKeyboardOpen,
    handleToolChange,
    handleDragStart,
    handleDragEnd,
    handleKeyboardOpen,
    handleKeyboardClose,
    updateLastInteractionTime,
  };
}; 