import { useCallback } from 'react';
import { ref, get, set } from 'firebase/database';
import { database } from '../config/firebase';
import { FixedGridCell } from '../types/fixedGrid';

export const useSplitCells = () => {
  const splitCells = useCallback(async (selectedCellIds: string[]) => {
    try {
      const cellsRef = ref(database, 'sharedBoardData/fixedCells');
      const snapshot = await get(cellsRef);
      const cells = snapshot.val() || {};

      // 선택된 셀들의 병합 그룹 식별
      const mergedGroups = new Map<string, string[]>();
      selectedCellIds.forEach(id => {
        const cell = cells[id] as FixedGridCell;
        if (cell?.mergedRoot) {
          const group = mergedGroups.get(cell.mergedRoot) || [];
          group.push(id);
          mergedGroups.set(cell.mergedRoot, group);
        }
      });

      // 각 병합 그룹 분할
      const updatedCells = { ...cells };
      mergedGroups.forEach((groupIds, rootId) => {
        const rootCell = cells[rootId] as FixedGridCell;
        if (!rootCell) return;

        // 루트 셀 복원
        updatedCells[rootId] = {
          ...rootCell,
          merged: false,
          mergedRoot: null,
          rowspan: 1,
          colspan: 1,
        };

        // 다른 셀들 복원
        groupIds.forEach(id => {
          if (id !== rootId) {
            updatedCells[id] = {
              ...cells[id],
              merged: false,
              mergedRoot: null,
            };
          }
        });
      });

      // Firebase 업데이트
      await set(cellsRef, updatedCells);
    } catch (error) {
      console.error('셀 분할 실패:', error);
    }
  }, []);

  return { splitCells };
}; 