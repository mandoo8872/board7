import { useCallback } from 'react';
import { ref, get, set } from 'firebase/database';
import { database } from '../config/firebase';
import { FixedGridCell } from '../types/fixedGrid';

type CellStyleUpdate = Partial<Pick<
  FixedGridCell,
  | 'fontSize'
  | 'fontColor'
  | 'backgroundColor'
  | 'borderStyle'
  | 'borderWidth'
  | 'borderColor'
  | 'textAlign'
  | 'verticalAlign'
>>;

export const useUpdateCellStyle = () => {
  const updateCellStyle = useCallback(async (cellId: string, style: CellStyleUpdate) => {
    try {
      const cellRef = ref(database, `sharedBoardData/fixedCells/${cellId}`);
      const snapshot = await get(cellRef);
      const cell = snapshot.val();

      if (cell) {
        await set(cellRef, {
          ...cell,
          ...style,
        });
      }
    } catch (error) {
      console.error('셀 스타일 업데이트 실패:', error);
    }
  }, []);

  return { updateCellStyle };
}; 