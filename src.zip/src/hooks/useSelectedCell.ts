import { useState, useCallback } from 'react';
import { FixedGridCell } from '../types/fixedGrid';

export const useSelectedCell = () => {
  const [selectedCell, setSelectedCell] = useState<FixedGridCell | null>(null);

  const selectCell = useCallback((cell: FixedGridCell | null) => {
    setSelectedCell(cell);
  }, []);

  return {
    selectedCell,
    selectCell,
  };
}; 