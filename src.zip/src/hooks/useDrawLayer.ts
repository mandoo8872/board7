import { useState, useCallback } from 'react';
import { ref, onValue, set } from 'firebase/database';
import { database } from '../config/firebase';

interface Stroke {
  path: string;
  color: string;
  width: number;
}

export const useDrawLayer = () => {
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPoints, setCurrentPoints] = useState<number[][]>([]);
  const [currentTool, setCurrentTool] = useState<'pen' | 'eraser'>('pen');

  // Firebase에서 스트로크 데이터 구독
  const strokesRef = ref(database, 'sharedBoardData/strokes');
  onValue(strokesRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      const strokesArray = Object.values(data) as Stroke[];
      setStrokes(strokesArray);
    }
  });

  const startDrawing = useCallback((x: number, y: number) => {
    setIsDrawing(true);
    setCurrentPoints([[x, y]]);
  }, []);

  const draw = useCallback((x: number, y: number) => {
    if (!isDrawing) return;

    setCurrentPoints(prev => [...prev, [x, y]]);
  }, [isDrawing]);

  const endDrawing = useCallback(async () => {
    if (!isDrawing || currentPoints.length < 2) {
      setIsDrawing(false);
      setCurrentPoints([]);
      return;
    }

    try {
      const path = currentPoints.reduce((acc, point, index) => {
        const [x, y] = point;
        return index === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
      }, '');

      const newStroke: Stroke = {
        path,
        color: currentTool === 'pen' ? '#000000' : '#ffffff',
        width: 2,
      };

      const updatedStrokes = [...strokes, newStroke];
      await set(strokesRef, updatedStrokes);

      setIsDrawing(false);
      setCurrentPoints([]);
    } catch (error) {
      console.error('스트로크 저장 실패:', error);
    }
  }, [isDrawing, currentPoints, currentTool, strokes]);

  const clearStrokes = useCallback(async () => {
    try {
      await set(strokesRef, []);
    } catch (error) {
      console.error('스트로크 삭제 실패:', error);
    }
  }, []);

  const undoStroke = useCallback(async () => {
    try {
      const updatedStrokes = strokes.slice(0, -1);
      await set(strokesRef, updatedStrokes);
    } catch (error) {
      console.error('스트로크 실행 취소 실패:', error);
    }
  }, [strokes]);

  const redoStroke = useCallback(async () => {
    // TODO: 구현
  }, []);

  return {
    strokes,
    isDrawing,
    currentPoints,
    currentTool,
    startDrawing,
    draw,
    endDrawing,
    setTool: setCurrentTool,
    clearStrokes,
    undoStroke,
    redoStroke,
  };
}; 