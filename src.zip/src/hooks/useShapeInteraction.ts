import { useRef, useState, useCallback } from 'react';
import { ref, update } from 'firebase/database';
import { database } from '../utils/firebase';
import { BoardObject } from '../types';

interface InteractionState {
  isDragging: boolean;
  isResizing: boolean;
  startX: number;
  startY: number;
  startWidth: number;
  startHeight: number;
  resizeDirection: string | null;
}

export const useShapeInteraction = (shape: BoardObject, isViewPage: boolean) => {
  const elementRef = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<InteractionState>({
    isDragging: false,
    isResizing: false,
    startX: 0,
    startY: 0,
    startWidth: 0,
    startHeight: 0,
    resizeDirection: null,
  });

  const updateShapeInFirebase = useCallback(async (updates: Partial<BoardObject>) => {
    try {
      const shapeRef = ref(database, `sharedBoardData/shapes/${shape.id}`);
      await update(shapeRef, updates);
    } catch (error) {
      console.error('객체 업데이트 실패:', error);
    }
  }, [shape.id]);

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    e.stopPropagation();
    
    const target = e.target as HTMLElement;
    const isResizeHandle = target.classList.contains('resize-handle');
    
    if (isResizeHandle && shape.resizable) {
      setState(prev => ({
        ...prev,
        isResizing: true,
        startX: e.clientX,
        startY: e.clientY,
        startWidth: shape.width,
        startHeight: shape.height,
        resizeDirection: target.dataset.direction || null,
      }));
    } else if (!shape.locked) {
      setState(prev => ({
        ...prev,
        isDragging: true,
        startX: e.clientX - shape.x,
        startY: e.clientY - shape.y,
      }));
    }

    // 선택 상태 업데이트
    if (!isViewPage || shape.type === 'checkbox-text') {
      updateShapeInFirebase({ selected: true });
    }
  }, [shape, isViewPage, updateShapeInFirebase]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (state.isDragging) {
      const newX = e.clientX - state.startX;
      const newY = e.clientY - state.startY;
      
      updateShapeInFirebase({ x: newX, y: newY });
    } else if (state.isResizing && state.resizeDirection) {
      const { startX, startY, startWidth, startHeight, resizeDirection } = state;
      let newWidth = startWidth;
      let newHeight = startHeight;

      if (resizeDirection.includes('e')) {
        newWidth = startWidth + (e.clientX - startX);
      }
      if (resizeDirection.includes('w')) {
        newWidth = startWidth - (e.clientX - startX);
      }
      if (resizeDirection.includes('s')) {
        newHeight = startHeight + (e.clientY - startY);
      }
      if (resizeDirection.includes('n')) {
        newHeight = startHeight - (e.clientY - startY);
      }

      updateShapeInFirebase({
        width: Math.max(50, newWidth),
        height: Math.max(50, newHeight),
      });
    }
  }, [state, updateShapeInFirebase]);

  const handlePointerUp = useCallback(() => {
    setState(prev => ({
      ...prev,
      isDragging: false,
      isResizing: false,
      resizeDirection: null,
    }));
  }, []);

  return {
    elementRef,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp,
    isDragging: state.isDragging,
    isResizing: state.isResizing,
  };
}; 