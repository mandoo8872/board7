import { useState, useCallback } from 'react';
import { ref, get, set } from 'firebase/database';
import { database } from '../config/firebase';

interface HistoryState {
  shapes: any;
  strokes: any;
  fixedCells: any;
}

export const useUndoRedo = () => {
  const [undoStack, setUndoStack] = useState<HistoryState[]>([]);
  const [redoStack, setRedoStack] = useState<HistoryState[]>([]);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  const saveState = useCallback(async () => {
    try {
      const shapesRef = ref(database, 'sharedBoardData/shapes');
      const strokesRef = ref(database, 'sharedBoardData/strokes');
      const cellsRef = ref(database, 'sharedBoardData/fixedCells');

      const [shapesSnapshot, strokesSnapshot, cellsSnapshot] = await Promise.all([
        get(shapesRef),
        get(strokesRef),
        get(cellsRef),
      ]);

      const currentState: HistoryState = {
        shapes: shapesSnapshot.val() || {},
        strokes: strokesSnapshot.val() || {},
        fixedCells: cellsSnapshot.val() || {},
      };

      setUndoStack(prev => {
        const newStack = [...prev, currentState].slice(-50);
        setCanUndo(newStack.length > 0);
        return newStack;
      });
      setRedoStack([]);
      setCanRedo(false);
    } catch (error) {
      console.error('상태 저장 실패:', error);
    }
  }, []);

  const undo = useCallback(async () => {
    if (undoStack.length === 0) return;

    try {
      const currentState = undoStack[undoStack.length - 1];
      const previousState = undoStack[undoStack.length - 2];

      if (!previousState) return;

      const shapesRef = ref(database, 'sharedBoardData/shapes');
      const strokesRef = ref(database, 'sharedBoardData/strokes');
      const cellsRef = ref(database, 'sharedBoardData/fixedCells');

      await Promise.all([
        set(shapesRef, previousState.shapes),
        set(strokesRef, previousState.strokes),
        set(cellsRef, previousState.fixedCells),
      ]);

      setUndoStack(prev => {
        const newStack = prev.slice(0, -1);
        setCanUndo(newStack.length > 0);
        return newStack;
      });

      setRedoStack(prev => {
        const newStack = [...prev, currentState];
        setCanRedo(true);
        return newStack;
      });
    } catch (error) {
      console.error('실행 취소 실패:', error);
    }
  }, [undoStack]);

  const redo = useCallback(async () => {
    if (redoStack.length === 0) return;

    try {
      const nextState = redoStack[redoStack.length - 1];

      const shapesRef = ref(database, 'sharedBoardData/shapes');
      const strokesRef = ref(database, 'sharedBoardData/strokes');
      const cellsRef = ref(database, 'sharedBoardData/fixedCells');

      await Promise.all([
        set(shapesRef, nextState.shapes),
        set(strokesRef, nextState.strokes),
        set(cellsRef, nextState.fixedCells),
      ]);

      setUndoStack(prev => {
        const newStack = [...prev, nextState];
        setCanUndo(true);
        return newStack;
      });

      setRedoStack(prev => {
        const newStack = prev.slice(0, -1);
        setCanRedo(newStack.length > 0);
        return newStack;
      });
    } catch (error) {
      console.error('다시 실행 실패:', error);
    }
  }, [redoStack]);

  return {
    canUndo,
    canRedo,
    undo,
    redo,
    saveState,
  };
}; 