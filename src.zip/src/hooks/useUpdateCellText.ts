import { useCallback } from 'react';
import { ref, get, set } from 'firebase/database';
import { database } from '../config/firebase';

export const useUpdateCellText = () => {
  const updateCellText = useCallback(async (cellId: string, text: string) => {
    try {
      const cellRef = ref(database, `sharedBoardData/fixedCells/${cellId}`);
      const snapshot = await get(cellRef);
      const cell = snapshot.val();

      if (cell) {
        await set(cellRef, {
          ...cell,
          text,
        });
      }
    } catch (error) {
      console.error('셀 텍스트 업데이트 실패:', error);
    }
  }, []);

  return { updateCellText };
}; 